<?php
/**
 * Title: Contacto — formulário e informações
 * Slug: designeo-lite/contacto
 * Categories: designeo-lite
 * Description: Secção de contacto com informações à esquerda e formulário à direita.
 */
?>
<!-- wp:group {"align":"full","className":"dl-section","style":{"spacing":{"padding":{"top":"var:preset|spacing|8","bottom":"var:preset|spacing|8"}},"border":{"top":{"color":"var:preset|color|borda","width":"0.5px","style":"solid"}}},"backgroundColor":"fundo","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull dl-section has-fundo-background-color has-background" style="padding-top:var(--wp--preset--spacing--8);padding-bottom:var(--wp--preset--spacing--8);border-top-color:var(--wp--preset--color--borda);border-top-style:solid;border-top-width:0.5px">

  <!-- wp:columns {"isStackedOnMobile":true,"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|8"}}}} -->
  <div class="wp-block-columns is-not-stacked-on-mobile">

    <!-- wp:column {"width":"40%"} -->
    <div class="wp-block-column" style="flex-basis:40%">

      <!-- wp:paragraph {"style":{"color":{"text":"var:preset|color|texto-suave"},"typography":{"fontSize":"var:preset|font-size|xs","fontWeight":"500","letterSpacing":"0.14em","textTransform":"uppercase"}}} -->
      <p class="has-text-color" style="color:var(--wp--preset--color--texto-suave);font-size:var(--wp--preset--font-size--xs);font-weight:500;letter-spacing:0.14em;text-transform:uppercase">Contacto</p>
      <!-- /wp:paragraph -->

      <!-- wp:heading {"level":2,"fontSize":"3xl"} -->
      <h2 class="wp-block-heading has-3-xl-font-size">Fala<br>connosco.</h2>
      <!-- /wp:heading -->

      <!-- wp:paragraph {"style":{"color":{"text":"var:preset|color|texto-suave"},"typography":{"lineHeight":"1.7"}}} -->
      <p class="has-text-color" style="color:var(--wp--preset--color--texto-suave);line-height:1.7">Frase de convite ao contacto — disponibilidade, tempo de resposta, o que podem esperar.</p>
      <!-- /wp:paragraph -->

      <!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|3","margin":{"top":"var:preset|spacing|5"}}}} -->
      <div class="wp-block-group" style="margin-top:var(--wp--preset--spacing--5)">

        <!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|1"}}} -->
        <div class="wp-block-group">
          <!-- wp:paragraph {"style":{"typography":{"fontSize":"var:preset|font-size|xs","fontWeight":"500","letterSpacing":"0.1em","textTransform":"uppercase"},"color":{"text":"var:preset|color|texto-suave"}}} -->
          <p class="has-text-color" style="font-size:var(--wp--preset--font-size--xs);font-weight:500;letter-spacing:0.1em;text-transform:uppercase;color:var(--wp--preset--color--texto-suave)">Email</p>
          <!-- /wp:paragraph -->
          <!-- wp:paragraph {"style":{"typography":{"fontSize":"var:preset|font-size|medio"}}} -->
          <p style="font-size:var(--wp--preset--font-size--medio)">geral@negocio.pt</p>
          <!-- /wp:paragraph -->
        </div>
        <!-- /wp:group -->

        <!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|1"}}} -->
        <div class="wp-block-group">
          <!-- wp:paragraph {"style":{"typography":{"fontSize":"var:preset|font-size|xs","fontWeight":"500","letterSpacing":"0.1em","textTransform":"uppercase"},"color":{"text":"var:preset|color|texto-suave"}}} -->
          <p class="has-text-color" style="font-size:var(--wp--preset--font-size--xs);font-weight:500;letter-spacing:0.1em;text-transform:uppercase;color:var(--wp--preset--color--texto-suave)">Localização</p>
          <!-- /wp:paragraph -->
          <!-- wp:paragraph {"style":{"typography":{"fontSize":"var:preset|font-size|medio"}}} -->
          <p style="font-size:var(--wp--preset--font-size--medio)">Leiria, Portugal</p>
          <!-- /wp:paragraph -->
        </div>
        <!-- /wp:group -->

      </div>
      <!-- /wp:group -->

    </div>
    <!-- /wp:column -->

    <!-- wp:column {"width":"60%"} -->
    <div class="wp-block-column" style="flex-basis:60%">
      <!-- wp:html -->
      <div class="dl-contact-form">
        <form action="#" method="post">
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:1.5rem;margin-bottom:1.5rem">
            <div>
              <label style="display:block;font-size:0.75rem;font-weight:500;letter-spacing:0.1em;text-transform:uppercase;color:var(--wp--preset--color--texto-suave);margin-bottom:0.5rem">Nome</label>
              <input type="text" name="nome" placeholder="O teu nome" required>
            </div>
            <div>
              <label style="display:block;font-size:0.75rem;font-weight:500;letter-spacing:0.1em;text-transform:uppercase;color:var(--wp--preset--color--texto-suave);margin-bottom:0.5rem">Email</label>
              <input type="email" name="email" placeholder="email@exemplo.com" required>
            </div>
          </div>
          <div style="margin-bottom:1.5rem">
            <label style="display:block;font-size:0.75rem;font-weight:500;letter-spacing:0.1em;text-transform:uppercase;color:var(--wp--preset--color--texto-suave);margin-bottom:0.5rem">Assunto</label>
            <input type="text" name="assunto" placeholder="Sobre o quê queres falar?">
          </div>
          <div style="margin-bottom:2rem">
            <label style="display:block;font-size:0.75rem;font-weight:500;letter-spacing:0.1em;text-transform:uppercase;color:var(--wp--preset--color--texto-suave);margin-bottom:0.5rem">Mensagem</label>
            <textarea name="mensagem" placeholder="A tua mensagem..." rows="5" required></textarea>
          </div>
          <button type="submit" style="padding:0.8rem 1.75rem;font-size:0.875rem;font-weight:500;letter-spacing:0.04em;text-transform:uppercase;background:#1a1a18;color:#fff;border:none;border-radius:2px;cursor:pointer">Enviar mensagem</button>
        </form>
      </div>
      <!-- /wp:html -->
    </div>
    <!-- /wp:column -->

  </div>
  <!-- /wp:columns -->

</div>
<!-- /wp:group -->
