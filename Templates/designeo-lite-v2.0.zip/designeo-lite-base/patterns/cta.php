<?php
/**
 * Title: CTA — chamada à acção
 * Slug: designeo-lite/cta
 * Categories: designeo-lite
 * Description: Secção de chamada à acção com fundo escuro, título e botão.
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|8","bottom":"var:preset|spacing|8"}}},"backgroundColor":"fundo-escuro","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull has-fundo-escuro-background-color has-background" style="padding-top:var(--wp--preset--spacing--8);padding-bottom:var(--wp--preset--spacing--8)">

  <!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|4"}},"layout":{"type":"constrained","contentSize":"600px"}} -->
  <div class="wp-block-group">

    <!-- wp:heading {"level":2,"textAlign":"center","fontSize":"3xl","style":{"color":{"text":"#ffffff"}}} -->
    <h2 class="wp-block-heading has-text-align-center has-3-xl-font-size has-text-color" style="color:#ffffff">Pronto para começar?<br>Fala connosco.</h2>
    <!-- /wp:heading -->

    <!-- wp:paragraph {"align":"center","style":{"color":{"text":"#9b9b96"},"typography":{"fontSize":"var:preset|font-size|grande","lineHeight":"1.6"}}} -->
    <p class="has-text-align-center has-text-color" style="color:#9b9b96;font-size:var(--wp--preset--font-size--grande);line-height:1.6">Uma frase que reforça a proposta de valor e convida à acção directa.</p>
    <!-- /wp:paragraph -->

    <!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"},"style":{"spacing":{"margin":{"top":"var:preset|spacing|4"}}}} -->
    <div class="wp-block-buttons" style="margin-top:var(--wp--preset--spacing--4)">
      <!-- wp:button {"style":{"color":{"background":"#ffffff","text":"#1a1a18"},"border":{"radius":"2px"}}} -->
      <div class="wp-block-button"><a class="wp-block-button__link has-text-color has-background wp-element-button" style="color:#1a1a18;background-color:#ffffff;border-radius:2px">Entrar em contacto</a></div>
      <!-- /wp:button -->
    </div>
    <!-- /wp:buttons -->

  </div>
  <!-- /wp:group -->

</div>
<!-- /wp:group -->
