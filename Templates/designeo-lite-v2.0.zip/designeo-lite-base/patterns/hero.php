<?php
/**
 * Title: Hero — título e CTA
 * Slug: designeo-lite/hero
 * Categories: designeo-lite, featured
 * Description: Secção hero com eyebrow, título principal, subtítulo e botões de acção.
 */
?>
<!-- wp:group {"align":"full","className":"dl-section","style":{"spacing":{"padding":{"top":"var:preset|spacing|9","bottom":"var:preset|spacing|9"}}},"backgroundColor":"fundo","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull dl-section has-fundo-background-color has-background" style="padding-top:var(--wp--preset--spacing--9);padding-bottom:var(--wp--preset--spacing--9)">

  <!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|4"}},"layout":{"type":"constrained","contentSize":"680px"}} -->
  <div class="wp-block-group">

    <!-- wp:paragraph {"className":"dl-hero-eyebrow","style":{"color":{"text":"var:preset|color|texto-suave"},"typography":{"fontSize":"var:preset|font-size|xs","fontWeight":"500","letterSpacing":"0.14em","textTransform":"uppercase"}}} -->
    <p class="dl-hero-eyebrow has-text-color" style="color:var(--wp--preset--color--texto-suave);font-size:var(--wp--preset--font-size--xs);font-weight:500;letter-spacing:0.14em;text-transform:uppercase">O teu negócio · Localização</p>
    <!-- /wp:paragraph -->

    <!-- wp:heading {"level":1,"fontSize":"4xl"} -->
    <h1 class="wp-block-heading has-4-xl-font-size">A headline que define<br>o teu negócio.</h1>
    <!-- /wp:heading -->

    <!-- wp:paragraph {"style":{"color":{"text":"var:preset|color|texto-suave"},"typography":{"fontSize":"var:preset|font-size|grande","lineHeight":"1.6"}},"textColor":"texto-suave"} -->
    <p class="has-texto-suave-color has-text-color" style="font-size:var(--wp--preset--font-size--grande);line-height:1.6">Subtítulo que complementa a headline — explica o valor da proposta em uma ou duas frases directas e claras.</p>
    <!-- /wp:paragraph -->

    <!-- wp:buttons {"style":{"spacing":{"blockGap":"var:preset|spacing|3","margin":{"top":"var:preset|spacing|4"}}}} -->
    <div class="wp-block-buttons" style="margin-top:var(--wp--preset--spacing--4)">
      <!-- wp:button -->
      <div class="wp-block-button"><a class="wp-block-button__link wp-element-button">Ver serviços</a></div>
      <!-- /wp:button -->
      <!-- wp:button {"className":"is-style-outline"} -->
      <div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button">Saber mais</a></div>
      <!-- /wp:button -->
    </div>
    <!-- /wp:buttons -->

  </div>
  <!-- /wp:group -->

</div>
<!-- /wp:group -->
