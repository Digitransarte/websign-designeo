<?php
/**
 * Title: Serviços — grid de 3
 * Slug: designeo-lite/servicos
 * Categories: designeo-lite
 * Description: Grid com 3 serviços ou características, com número, título e descrição.
 */
?>
<!-- wp:group {"align":"full","className":"dl-section","style":{"spacing":{"padding":{"top":"var:preset|spacing|8","bottom":"var:preset|spacing|8"}},"border":{"top":{"color":"var:preset|color|borda","width":"0.5px","style":"solid"}}},"backgroundColor":"fundo","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull dl-section has-fundo-background-color has-background" style="padding-top:var(--wp--preset--spacing--8);padding-bottom:var(--wp--preset--spacing--8);border-top-color:var(--wp--preset--color--borda);border-top-style:solid;border-top-width:0.5px">

  <!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|2","margin":{"bottom":"var:preset|spacing|7"}}},"layout":{"type":"constrained","contentSize":"600px"}} -->
  <div class="wp-block-group" style="margin-bottom:var(--wp--preset--spacing--7)">
    <!-- wp:paragraph {"style":{"color":{"text":"var:preset|color|texto-suave"},"typography":{"fontSize":"var:preset|font-size|xs","fontWeight":"500","letterSpacing":"0.14em","textTransform":"uppercase"}}} -->
    <p class="has-text-color" style="color:var(--wp--preset--color--texto-suave);font-size:var(--wp--preset--font-size--xs);font-weight:500;letter-spacing:0.14em;text-transform:uppercase">Serviços</p>
    <!-- /wp:paragraph -->
    <!-- wp:heading {"level":2,"fontSize":"3xl"} -->
    <h2 class="wp-block-heading has-3-xl-font-size">O que fazemos por ti.</h2>
    <!-- /wp:heading -->
  </div>
  <!-- /wp:group -->

  <!-- wp:columns {"isStackedOnMobile":true,"style":{"spacing":{"blockGap":{"top":"var:preset|spacing|6","left":"var:preset|spacing|6"}}}} -->
  <div class="wp-block-columns is-not-stacked-on-mobile">

    <!-- wp:column -->
    <div class="wp-block-column">
      <!-- wp:paragraph {"className":"dl-service-number","style":{"color":{"text":"var:preset|color|texto-suave"},"typography":{"fontSize":"var:preset|font-size|xs","fontWeight":"500","letterSpacing":"0.1em","textTransform":"uppercase"}}} -->
      <p class="dl-service-number has-text-color" style="color:var(--wp--preset--color--texto-suave);font-size:var(--wp--preset--font-size--xs);font-weight:500;letter-spacing:0.1em;text-transform:uppercase">01</p>
      <!-- /wp:paragraph -->
      <!-- wp:separator {"style":{"color":{"background":"var:preset|color|borda"},"spacing":{"margin":{"top":"0","bottom":"var:preset|spacing|4"}}}} -->
      <hr class="wp-block-separator has-alpha-channel-opacity has-text-color" style="background-color:var(--wp--preset--color--borda);margin-top:0;margin-bottom:var(--wp--preset--spacing--4)"/>
      <!-- /wp:separator -->
      <!-- wp:heading {"level":3,"fontSize":"xl"} -->
      <h3 class="wp-block-heading has-xl-font-size">Primeiro serviço</h3>
      <!-- /wp:heading -->
      <!-- wp:paragraph {"style":{"color":{"text":"var:preset|color|texto-suave"}}} -->
      <p class="has-text-color" style="color:var(--wp--preset--color--texto-suave)">Descrição clara e directa do que inclui este serviço e o benefício principal para o cliente.</p>
      <!-- /wp:paragraph -->
    </div>
    <!-- /wp:column -->

    <!-- wp:column -->
    <div class="wp-block-column">
      <!-- wp:paragraph {"className":"dl-service-number","style":{"color":{"text":"var:preset|color|texto-suave"},"typography":{"fontSize":"var:preset|font-size|xs","fontWeight":"500","letterSpacing":"0.1em","textTransform":"uppercase"}}} -->
      <p class="dl-service-number has-text-color" style="color:var(--wp--preset--color--texto-suave);font-size:var(--wp--preset--font-size--xs);font-weight:500;letter-spacing:0.1em;text-transform:uppercase">02</p>
      <!-- /wp:paragraph -->
      <!-- wp:separator {"style":{"color":{"background":"var:preset|color|borda"},"spacing":{"margin":{"top":"0","bottom":"var:preset|spacing|4"}}}} -->
      <hr class="wp-block-separator has-alpha-channel-opacity has-text-color" style="background-color:var(--wp--preset--color--borda);margin-top:0;margin-bottom:var(--wp--preset--spacing--4)"/>
      <!-- /wp:separator -->
      <!-- wp:heading {"level":3,"fontSize":"xl"} -->
      <h3 class="wp-block-heading has-xl-font-size">Segundo serviço</h3>
      <!-- /wp:heading -->
      <!-- wp:paragraph {"style":{"color":{"text":"var:preset|color|texto-suave"}}} -->
      <p class="has-text-color" style="color:var(--wp--preset--color--texto-suave)">Descrição clara e directa do que inclui este serviço e o benefício principal para o cliente.</p>
      <!-- /wp:paragraph -->
    </div>
    <!-- /wp:column -->

    <!-- wp:column -->
    <div class="wp-block-column">
      <!-- wp:paragraph {"className":"dl-service-number","style":{"color":{"text":"var:preset|color|texto-suave"},"typography":{"fontSize":"var:preset|font-size|xs","fontWeight":"500","letterSpacing":"0.1em","textTransform":"uppercase"}}} -->
      <p class="dl-service-number has-text-color" style="color:var(--wp--preset--color--texto-suave);font-size:var(--wp--preset--font-size--xs);font-weight:500;letter-spacing:0.1em;text-transform:uppercase">03</p>
      <!-- /wp:paragraph -->
      <!-- wp:separator {"style":{"color":{"background":"var:preset|color|borda"},"spacing":{"margin":{"top":"0","bottom":"var:preset|spacing|4"}}}} -->
      <hr class="wp-block-separator has-alpha-channel-opacity has-text-color" style="background-color:var(--wp--preset--color--borda);margin-top:0;margin-bottom:var(--wp--preset--spacing--4)"/>
      <!-- /wp:separator -->
      <!-- wp:heading {"level":3,"fontSize":"xl"} -->
      <h3 class="wp-block-heading has-xl-font-size">Terceiro serviço</h3>
      <!-- /wp:heading -->
      <!-- wp:paragraph {"style":{"color":{"text":"var:preset|color|texto-suave"}}} -->
      <p class="has-text-color" style="color:var(--wp--preset--color--texto-suave)">Descrição clara e directa do que inclui este serviço e o benefício principal para o cliente.</p>
      <!-- /wp:paragraph -->
    </div>
    <!-- /wp:column -->

  </div>
  <!-- /wp:columns -->

</div>
<!-- /wp:group -->
