<?php
/**
 * Title: Sobre — texto e imagem
 * Slug: designeo-lite/sobre
 * Categories: designeo-lite
 * Description: Secção sobre com texto à esquerda e imagem à direita (ou invertido).
 */
?>
<!-- wp:group {"align":"full","className":"dl-section","style":{"spacing":{"padding":{"top":"var:preset|spacing|8","bottom":"var:preset|spacing|8"}},"border":{"top":{"color":"var:preset|color|borda","width":"0.5px","style":"solid"}}},"backgroundColor":"fundo-suave","layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull dl-section has-fundo-suave-background-color has-background" style="padding-top:var(--wp--preset--spacing--8);padding-bottom:var(--wp--preset--spacing--8);border-top-color:var(--wp--preset--color--borda);border-top-style:solid;border-top-width:0.5px">

  <!-- wp:columns {"isStackedOnMobile":true,"verticalAlignment":"center","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|8"}}}} -->
  <div class="wp-block-columns is-not-stacked-on-mobile are-vertically-aligned-center">

    <!-- wp:column {"width":"55%"} -->
    <div class="wp-block-column" style="flex-basis:55%">

      <!-- wp:paragraph {"style":{"color":{"text":"var:preset|color|texto-suave"},"typography":{"fontSize":"var:preset|font-size|xs","fontWeight":"500","letterSpacing":"0.14em","textTransform":"uppercase"}}} -->
      <p class="has-text-color" style="color:var(--wp--preset--color--texto-suave);font-size:var(--wp--preset--font-size--xs);font-weight:500;letter-spacing:0.14em;text-transform:uppercase">Sobre nós</p>
      <!-- /wp:paragraph -->

      <!-- wp:heading {"level":2,"fontSize":"3xl"} -->
      <h2 class="wp-block-heading has-3-xl-font-size">Uma frase que resume<br>a vossa história.</h2>
      <!-- /wp:heading -->

      <!-- wp:paragraph {"style":{"color":{"text":"var:preset|color|texto-suave"},"typography":{"lineHeight":"1.75"}}} -->
      <p class="has-text-color" style="color:var(--wp--preset--color--texto-suave);line-height:1.75">Primeiro parágrafo sobre o negócio — origem, motivação, o que vos distingue. Texto autêntico que cria ligação com o visitante.</p>
      <!-- /wp:paragraph -->

      <!-- wp:paragraph {"style":{"color":{"text":"var:preset|color|texto-suave"},"typography":{"lineHeight":"1.75"}}} -->
      <p class="has-text-color" style="color:var(--wp--preset--color--texto-suave);line-height:1.75">Segundo parágrafo — valores, abordagem, porquê escolher este negócio em vez da concorrência.</p>
      <!-- /wp:paragraph -->

      <!-- wp:buttons {"style":{"spacing":{"margin":{"top":"var:preset|spacing|4"}}}} -->
      <div class="wp-block-buttons" style="margin-top:var(--wp--preset--spacing--4)">
        <!-- wp:button {"className":"is-style-ghost"} -->
        <div class="wp-block-button is-style-ghost"><a class="wp-block-button__link wp-element-button">Conhecer a equipa →</a></div>
        <!-- /wp:button -->
      </div>
      <!-- /wp:buttons -->

    </div>
    <!-- /wp:column -->

    <!-- wp:column {"width":"45%"} -->
    <div class="wp-block-column" style="flex-basis:45%">
      <!-- wp:image {"sizeSlug":"large","style":{"border":{"radius":"4px"}},"aspectRatio":"4/5","scale":"cover"} -->
      <figure class="wp-block-image size-large" style="border-radius:4px"><img src="" alt="Sobre o negócio" style="aspect-ratio:4/5;object-fit:cover"/></figure>
      <!-- /wp:image -->
    </div>
    <!-- /wp:column -->

  </div>
  <!-- /wp:columns -->

</div>
<!-- /wp:group -->
