<?php // Silence is golden. WordPress FSE uses HTML templates.
