<?php
/**
 * Designeo Lite — functions.php v2
 * Base sólida. Mínimo necessário, sem bloat.
 */

defined( 'ABSPATH' ) || exit;

// ── Theme setup ────────────────────────────────────────────────────────────────

add_action( 'after_setup_theme', function () {
    add_theme_support( 'wp-block-styles' );
    add_theme_support( 'editor-styles' );
    add_editor_style( 'assets/css/editor.css' );
    add_theme_support( 'html5', [
        'search-form', 'comment-form', 'comment-list',
        'gallery', 'caption', 'script', 'style'
    ] );
    add_theme_support( 'post-thumbnails' );
    add_post_type_support( 'page', 'excerpt' );

    load_theme_textdomain( 'designeo-lite', get_template_directory() . '/languages' );
} );

// ── Enqueue assets ─────────────────────────────────────────────────────────────

add_action( 'wp_enqueue_scripts', function () {
    $ver = wp_get_theme()->get( 'Version' );
    $uri = get_template_directory_uri();

    // CSS global
    wp_enqueue_style(
        'designeo-lite-global',
        $uri . '/assets/css/global.css',
        [],
        $ver
    );

    // JS do header (scroll detection) — defer, sem bloquear render
    wp_enqueue_script(
        'designeo-lite-header',
        $uri . '/assets/js/header.js',
        [],
        $ver,
        [ 'strategy' => 'defer', 'in_footer' => true ]
    );
} );

// ── Block pattern categories ───────────────────────────────────────────────────

add_action( 'init', function () {
    register_block_pattern_category(
        'designeo-lite',
        [ 'label' => __( 'Designeo Lite', 'designeo-lite' ) ]
    );
} );

// ── Segurança: limpar o <head> ─────────────────────────────────────────────────

remove_action( 'wp_head', 'wp_generator' );
remove_action( 'wp_head', 'rsd_link' );
remove_action( 'wp_head', 'wlwmanifest_link' );
remove_action( 'wp_head', 'wp_shortlink_wp_head' );
remove_action( 'wp_head', 'rest_output_link_wp_head' );
remove_action( 'template_redirect', 'rest_output_link_header', 11 );

// ── Segurança: cabeçalhos HTTP ─────────────────────────────────────────────────

add_action( 'send_headers', function () {
    if ( ! headers_sent() ) {
        header( 'X-Frame-Options: SAMEORIGIN' );
        header( 'X-Content-Type-Options: nosniff' );
        header( 'Referrer-Policy: strict-origin-when-cross-origin' );
        header( 'Permissions-Policy: camera=(), microphone=(), geolocation=()' );
    }
} );

// ── Performance: remover emoji scripts ────────────────────────────────────────

remove_action( 'wp_head',             'print_emoji_detection_script', 7 );
remove_action( 'admin_print_scripts', 'print_emoji_detection_script'    );
remove_action( 'wp_print_styles',     'print_emoji_styles'               );
remove_action( 'admin_print_styles',  'print_emoji_styles'               );
remove_filter( 'the_content_feed',    'wp_staticize_emoji'               );
remove_filter( 'comment_text_rss',    'wp_staticize_emoji'               );
remove_filter( 'wp_mail',             'wp_staticize_emoji_for_email'     );

// ── Segurança: REST API — bloqueia listagem pública de utilizadores ────────────

add_filter( 'rest_endpoints', function ( $endpoints ) {
    if ( isset( $endpoints['/wp/v2/users'] ) ) {
        foreach ( $endpoints['/wp/v2/users'] as $key => $endpoint ) {
            if ( isset( $endpoint['methods'] ) && $endpoint['methods'] === 'GET' ) {
                $endpoints['/wp/v2/users'][ $key ]['permission_callback'] = function () {
                    return current_user_can( 'list_users' );
                };
            }
        }
    }
    if ( isset( $endpoints['/wp/v2/users/(?P<id>[\d]+)'] ) ) {
        foreach ( $endpoints['/wp/v2/users/(?P<id>[\d]+)'] as $key => $endpoint ) {
            if ( isset( $endpoint['methods'] ) && $endpoint['methods'] === 'GET' ) {
                $endpoints['/wp/v2/users/(?P<id>[\d]+)'][ $key ]['permission_callback'] = function () {
                    return current_user_can( 'list_users' );
                };
            }
        }
    }
    return $endpoints;
} );

// ── Erros PHP: nunca visíveis no frontend ─────────────────────────────────────

if ( ! defined( 'WP_DEBUG' ) || ! WP_DEBUG ) {
    @ini_set( 'display_errors', 0 );
    @error_reporting( 0 );
}
