/**
 * Designeo Lite — header.js
 * Adiciona classe 'is-scrolled' ao header quando a página tem scroll.
 * Permite aplicar sombra via CSS sem JavaScript pesado.
 */
(function () {
  'use strict';

  const header = document.querySelector('.dl-site-header');
  if (!header) return;

  let ticking = false;

  function onScroll() {
    if (!ticking) {
      requestAnimationFrame(function () {
        if (window.scrollY > 10) {
          header.classList.add('is-scrolled');
        } else {
          header.classList.remove('is-scrolled');
        }
        ticking = false;
      });
      ticking = true;
    }
  }

  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll(); // Estado inicial
})();
