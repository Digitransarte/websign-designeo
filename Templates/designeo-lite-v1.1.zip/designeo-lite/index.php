<?php
// Silence is golden. WordPress FSE themes use HTML templates.
