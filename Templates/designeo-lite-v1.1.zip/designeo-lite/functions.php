<?php
/**
 * Designeo Lite — functions.php
 * Base sólida. Mínimo necessário, sem bloat.
 */

defined( 'ABSPATH' ) || exit;

// ── Theme setup ────────────────────────────────────────────────────────────────

add_action( 'after_setup_theme', function () {
    add_theme_support( 'wp-block-styles' );
    add_theme_support( 'editor-styles' );
    add_editor_style( 'assets/css/editor.css' );
    add_theme_support( 'html5', [ 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'script', 'style' ] );
    add_theme_support( 'post-thumbnails' );

    load_theme_textdomain( 'designeo-lite', get_template_directory() . '/languages' );
} );

// ── Enqueue global styles ──────────────────────────────────────────────────────

add_action( 'wp_enqueue_scripts', function () {
    wp_enqueue_style(
        'designeo-lite-global',
        get_template_directory_uri() . '/assets/css/global.css',
        [],
        wp_get_theme()->get( 'Version' )
    );
} );

// ── Block pattern categories ───────────────────────────────────────────────────

add_action( 'init', function () {
    register_block_pattern_category(
        'designeo-lite',
        [ 'label' => __( 'Designeo Lite', 'designeo-lite' ) ]
    );
} );

// ── Segurança: remover informação desnecessária do <head> ──────────────────────

// Remove versão do WordPress
remove_action( 'wp_head', 'wp_generator' );

// Remove links de feed automáticos (opcional — descomenta se não usas feed)
// remove_action( 'wp_head', 'feed_links', 2 );
// remove_action( 'wp_head', 'feed_links_extra', 3 );

// Remove RSD e WLW links (ferramentas antigas de publicação)
remove_action( 'wp_head', 'rsd_link' );
remove_action( 'wp_head', 'wlwmanifest_link' );

// Remove shortlink
remove_action( 'wp_head', 'wp_shortlink_wp_head' );

// Remove REST API link do head (a API continua a funcionar — só remove o link de descoberta)
remove_action( 'wp_head', 'rest_output_link_wp_head' );
remove_action( 'template_redirect', 'rest_output_link_header', 11 );

// ── Performance: remover emoji scripts ────────────────────────────────────────

remove_action( 'wp_head',             'print_emoji_detection_script', 7 );
remove_action( 'admin_print_scripts', 'print_emoji_detection_script'    );
remove_action( 'wp_print_styles',     'print_emoji_styles'               );
remove_action( 'admin_print_styles',  'print_emoji_styles'               );
remove_filter( 'the_content_feed',    'wp_staticize_emoji'               );
remove_filter( 'comment_text_rss',    'wp_staticize_emoji'               );
remove_filter( 'wp_mail',             'wp_staticize_emoji_for_email'     );

// ── Segurança: cabeçalhos HTTP ─────────────────────────────────────────────────

add_action( 'send_headers', function () {
    // Previne clickjacking
    header( 'X-Frame-Options: SAMEORIGIN' );
    // Previne MIME sniffing
    header( 'X-Content-Type-Options: nosniff' );
    // Referrer policy
    header( 'Referrer-Policy: strict-origin-when-cross-origin' );
} );

// ── Segurança: esconder erros PHP no frontend ──────────────────────────────────

if ( ! WP_DEBUG ) {
    ini_set( 'display_errors', 0 );
    error_reporting( 0 );
}

// ── REST API: restringir acesso a utilizadores não autenticados ────────────────
// (mantém a API funcional para o Studio mas bloqueia listagem pública de utilizadores)

add_filter( 'rest_endpoints', function ( $endpoints ) {
    if ( isset( $endpoints['/wp/v2/users'] ) ) {
        foreach ( $endpoints['/wp/v2/users'] as $key => $endpoint ) {
            if ( isset( $endpoint['methods'] ) && $endpoint['methods'] === 'GET' ) {
                $endpoints['/wp/v2/users'][ $key ]['permission_callback'] = function () {
                    return current_user_can( 'list_users' );
                };
            }
        }
    }
    return $endpoints;
} );

// ── Excerpts para páginas (útil para SEO e listagens) ─────────────────────────

add_post_type_support( 'page', 'excerpt' );
